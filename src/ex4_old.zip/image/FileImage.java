package image;

import javax.imageio.ImageIO;
import java.awt.*;
import java.io.File;
import java.io.IOException;

/**
 * A package-private class of the package image.
 * @author Dan Nirel
 */
class FileImage implements Image {
    private static final Color DEFAULT_COLOR = Color.WHITE;
    private final int imageWidth;
    private final int imageHeight;

    private final Color[][] pixelArray;

    public FileImage(String filename) throws IOException {
        java.awt.image.BufferedImage im = ImageIO.read(new File(filename));
        int origWidth = im.getWidth(), origHeight = im.getHeight();
        //im.getRGB(x, y)); getter for access to a specific RGB rates
        if (isPowerOfTwo(origHeight) && isPowerOfTwo(origWidth)) {
            this.imageWidth = origWidth;
            this.imageHeight = origHeight;
            pixelArray = new Color[imageHeight][imageWidth];
            for (int i = 0; i < imageHeight; i++) {
                for (int j = 0; j < imageWidth; j++) {
                    pixelArray[i][j] = new Color(im.getRGB(i, j));
                }
            }
        }
        else {
            int newWidth = findClosestPowerOfTwo(origWidth); //TODO: change
            int newHeight = findClosestPowerOfTwo(origHeight); //TODO: change
//            Color[][] paddedArray = new Color[newHeight][newWidth];
            this.imageHeight = newHeight;
            this.imageWidth = newWidth;
            pixelArray = new Color[newHeight][newWidth];
            int toPadRows = (newHeight - origHeight) / 2;
            int toPadCols = (newWidth - origWidth) / 2;
            for (int i = 0; i < newHeight; i++) {
                for (int j = 0; j < newWidth; j++) {
                    if (i < toPadCols || i >= (newWidth - toPadCols) || j < toPadRows || j >= (newHeight - toPadRows)) {
                        pixelArray[i][j] = DEFAULT_COLOR;
                    }
                    else {
                        pixelArray[i][j] = new Color(im.getRGB(i - toPadCols, j - toPadRows));
                    }
                }
            }
            System.out.println(pixelArray.length);
            System.out.println(pixelArray[0].length);
//            for (int k = 0; k < origHeight; k++) {
//                for (int l = 0; l < origWidth; l++) {
////                    System.out.println(k);
//                    paddedArray[k + toPadRows][l + toPadCols] = new Color(im.getRGB(l, k));
//                }
//            }
//            this.imageWidth = newWidth;
//            this.imageHeight = newHeight;
//            this.pixelArray = paddedArray;
            for (int k = 0; k < imageHeight; k++) {
                for (int l = 0; l < imageWidth; l++) {
                    if (pixelArray[k][l] == null) {
                        System.out.println("(" + k + "," + l + ")");
                    }
                }
            }
        }
    }

    @Override
    public int getWidth() {
        return this.imageWidth;
    }

    @Override
    public int getHeight() {
        return this.imageHeight;
    }

    @Override
    public Color getPixel(int x, int y) {
        return pixelArray[y][x];
    }

    private static int findClosestPowerOfTwo(int dimensionLength) {
        int closestPower = 1;
        while (closestPower < dimensionLength)
        {
            closestPower = closestPower << 1;
        }
        return  closestPower;
    }

    public static boolean isPowerOfTwo(int number) {
        if (number <= 0) {
            return false;
        }
        return (number & (number - 1)) == 0;
    }
}
