/**
 * Utility module for opening files from disk and iterating its pixels or sub-images.
 * @author Dan Nirel
 */
package image;