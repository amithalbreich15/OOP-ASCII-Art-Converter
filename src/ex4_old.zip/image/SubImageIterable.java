package image;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * A package-private class of the package image.
 * @author Dan Nirel
 */
class SubImageIterable<T> implements Iterable<T> {
    private final Image img;
    private final int subImageSize;
//    private Color[][] subImageArray;

    public SubImageIterable(
            Image img,int subImageSize) {
        this.img = img;
        this.subImageSize = subImageSize;
    }

    @Override
    public Iterator<T> iterator() {
        return new Iterator<T>() {
            int subimageRowIdx = 0, subimageColIdx = 0;

            @Override
            public boolean hasNext() { return subimageRowIdx < img.getHeight(); }

            @Override
            @SuppressWarnings("unchecked")
            public T next() {
                if (!hasNext())
                    throw new NoSuchElementException();
                var next = new SubImage(subImageSize,img, subimageRowIdx, subimageColIdx);
//                var next = new Color[subImageSize][subImageSize];
//                for (int i = 0; i < subImageSize; i++) {
//                    for (int j = 0; j < subImageSize; j++) {
//                        next[i][j] = img.getPixel(i + imageRow,j + imageCol);
//                    }
//                }
                subimageColIdx += subImageSize;
                if (subimageColIdx >= img.getWidth()) {
                    subimageColIdx = 0;
                    subimageRowIdx += subImageSize;
                }
                return (T) next;
            }
        };
    }
}

