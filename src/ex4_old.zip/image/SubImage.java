package image;

import java.awt.*;


class SubImage implements Image {
    private static final Color DEFAULT_COLOR = Color.WHITE;
    private final int subimageSize;
    private Color[][] subimageColorArr;


    SubImage(int subimageSize, Image image, int subimageRowIdx, int subimageColIdx) {
        this.subimageSize = subimageSize;
        this.subimageColorArr =  new Color[subimageSize][subimageSize];
        for (int i = 0; i < subimageSize; i++) {
            for (int j = 0; j < subimageSize; j++) {
                subimageColorArr[i][j] = image.getPixel(i + subimageRowIdx,j + subimageColIdx);
            }
        }
    }

    @Override
    public Color getPixel(int x, int y) {
        return subimageColorArr[x][y];
    }

    @Override
    public int getWidth() {
        return this.subimageSize;
    }

    @Override
    public int getHeight() {
        return this.subimageSize;
    }
}
