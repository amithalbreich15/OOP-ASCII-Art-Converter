/**
 * The module responsible for actually translating images to chars
 * @author Dan Nirel
 */
package ascii_art.img_to_char;