package ascii_art.img_to_char;

import java.awt.*;
import image.Image;
import java.util.HashMap;

public class BrightnessImgCharMatcher {
    private static final int RGB_MAX = 255;
    private static final int RESOLUTION = 16;
    private static final double MULT_RED_FOR_GREY = 0.2126;
    private static final double MULT_GREEN_FOR_GREY = 0.7152;
    private static final double MULT_BLUE_FOR_GREY = 0.0722;
    public static final String ERROR_BAD_IMAGE = "ERROR: BAD IMAGE";
    private final Image img;
    private final String font;
    private final HashMap<Image, Float> cache = new HashMap<>();

    public BrightnessImgCharMatcher(Image img, String font) {
        this.img = img;
        this.font = font;
        if (img == null){
            System.out.println(ERROR_BAD_IMAGE);
        }
    }

    public char[][] chooseChars(int numCharsInRow, Character[] charSet){
        float [] charToBrightness = charToBrightness(charSet);
        float[] charBrightnessLinearStretched = linearStretch(charToBrightness);
        return convertImageToAscii(numCharsInRow, charSet, charBrightnessLinearStretched);
    }

    private float[] charToBrightness(Character[] charSet){
         float[] brightnessArr = new float[charSet.length];
         if (charSet.length == 0){
             return brightnessArr;
             }
         for (int i = 0; i < charSet.length; i++) {
             int whiteCounter = 0;
             boolean[][] boolMatrix = CharRenderer.getImg(charSet[i], RESOLUTION, font);
             for(boolean[] boolRow: boolMatrix){
                 for (boolean boolValue: boolRow){
                     if(boolValue){
                         whiteCounter++;
                         }
                     }
                 }
             brightnessArr[i] = (float)whiteCounter/(RESOLUTION*RESOLUTION);
         }
         return brightnessArr;
    }

    private static float[] linearStretch(float[] charBrightnessArray) {
        float maxBrightness = 0;
        float minBrightness = 1;
        for (int i = 0; i < charBrightnessArray.length; i++) {
            if (charBrightnessArray[i] < minBrightness) {
                minBrightness = charBrightnessArray[i];
            }
            if (charBrightnessArray[i] > maxBrightness) {
                maxBrightness = charBrightnessArray[i];
            }
        }
        float[] linearStretchedArray = new float[charBrightnessArray.length];
        if (charBrightnessArray.length == 0  || maxBrightness == minBrightness)
        {
            return linearStretchedArray;
        }
        for (int i = 0; i < linearStretchedArray.length; i++) {
            linearStretchedArray[i] = (charBrightnessArray[i] - minBrightness) / (maxBrightness - minBrightness);
        }
        return linearStretchedArray;
    }

    private float imageAverageBrightness(Image subImage){
        if (cache.containsKey(subImage)){
            return cache.get(subImage);
        }
        float colorSum = 0;
        int pixelCounter = 0;
        for (Color pixel : subImage.pixels()) {
             colorSum += (pixel.getRed() * MULT_RED_FOR_GREY + pixel.getGreen() * MULT_GREEN_FOR_GREY +
                     pixel.getBlue() * MULT_BLUE_FOR_GREY)/RGB_MAX;
             pixelCounter++;
        }
        cache.put(subImage, colorSum / pixelCounter);
        return colorSum / pixelCounter;
    }

    private char[][] convertImageToAscii(int numCharsInRow, Character[] charList, float[] charBrightnessLinearStretched){
        int subImageSize = img.getWidth() / numCharsInRow;
        int charRows = img.getHeight()/subImageSize;
        int charCols = img.getHeight()/subImageSize;
        char[][] asciiArt = new char[charRows][charCols];
        if (charList.length == 0){
            return asciiArt;
        }
        int i = 0 , j = 0;
        for(Image subImage : img.SubimageIterator(subImageSize)) {
            float subImgAvgBrightness = imageAverageBrightness(subImage);
            int bestCharIndex = 0;
            float bestDistance = 1;
            for (int currIdx = 0; currIdx < charBrightnessLinearStretched.length; currIdx++) {
                float distance = charBrightnessLinearStretched[currIdx] - subImgAvgBrightness;
                if (Math.abs(distance) < bestDistance){
                    bestDistance = Math.abs(distance);
                    bestCharIndex = currIdx;
                }
            }
            asciiArt[i][j] = charList[bestCharIndex];
            j++;
            if (j == numCharsInRow){
                j = 0;
                i++;
            }
        }
        return asciiArt;
    }

//    /**
//     * Main function - runs the game in a new Bricker Game window.
//     * @param args - Environment args
//     */
//    public static void main(String[] args) {
//        Image img = Image.fromFile("board.jpeg");
//        BrightnessImgCharMatcher charMatcher = new BrightnessImgCharMatcher(img,"Ariel");
//        var chars = charMatcher.chooseChars(2, new Character[]{'m', 'o'});
//        System.out.println(Arrays.deepToString(chars));
//    }
}
