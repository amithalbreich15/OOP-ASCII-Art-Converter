package ascii_art;

import ascii_art.img_to_char.BrightnessImgCharMatcher;
import ascii_output.AsciiOutput;
import ascii_output.HtmlAsciiOutput;
import image.Image;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Stream;

public class Shell {
    private final int minCharsInRow;
    private final int maxCharsInRow;
    private int charsInRow;
    private final BrightnessImgCharMatcher brightnessImgCharMatcher;
    private final AsciiOutput asciiOutput;
    private boolean console = false;
    private Set<Character>  charSet = new HashSet<>();

    private Image img;
    private static final String CONSOLE_GUI = "<<<";
    private final Scanner input = new Scanner(System.in);
    private static final char FIRST_ASCII = ' ';
    private static final char LAST_ASCII = '~';
    private static final String SHOW_CHARS = "chars";
    private static final String ADD_CHARS = "add";
    private static final String REMOVE_CHARS = "remove";
    private static final String RES_CHANGE = "res";
    private static final String RENDER = "render";
    private static final String CONSOLE = "console";
    private static final String CMD_EXIT = "exit";
    private static final int INITIAL_CHARS_IN_ROW = 64;
    private static final int MIN_PIXELS_PER_CHAR = 2;
    private static final String FONT_NAME = "Courier New";
    private static final String OUTPUT_FILENAME = "out.html";
    private static final String INITIAL_CHARS_RANGE = "0-9";
//    private static final String RES_MAX_MSG = "Resolution is already at maximum value.";
    private static final String WIDTH_SET_TO = "Width set to: ";
    private static final String RES_UP = "up";
    private static final String RES_DOWN = "down";
    private static final String RESOLUTION_ERR_MSG = "Did not change due to exceeding boundaries";
    private static final String RES_FORMAT = "ERROR: resolution change format is: res <up/down>";
    private static final String ERROR_INVALID_OPERATION = "ERROR: invalid operation";
    private static final String ERROR_INVALID_ADD_FORMAT = "ERROR: Did not remove due to incorrect format";
    private static final String INVALID_COMMAND_ERROR = "ERROR: Did not executed due to incorrect command";
    private static final String CHARS_FORMAT = "Show Chars command format is just: 'chars'";
    private static final String RENDER_FORMAT = "Render command format is just: 'render'";
    private static final String CONSOLE_FORMAT = "Console command format is just: 'console'";
    public static final String ALL_CHARS = "all";
    public static final char SPACE_CHAR = ' ';
    public static final char CHAR_HYPHEN = '-';
    public static final String SPACE = " ";
    private static final int RESOLUTION_FACTOR = 2;

    public Shell(Image img) {
        minCharsInRow = Math.max(1, img.getWidth()/img.getHeight());
        maxCharsInRow = img.getWidth() / MIN_PIXELS_PER_CHAR;
        charsInRow = Math.max(Math.min(INITIAL_CHARS_IN_ROW,maxCharsInRow), minCharsInRow);
        brightnessImgCharMatcher = new BrightnessImgCharMatcher(img, FONT_NAME);
        asciiOutput = new HtmlAsciiOutput(OUTPUT_FILENAME, FONT_NAME);
        addChars(INITIAL_CHARS_RANGE);
    }

    private static char[] parseCharRange(String charString) {
        switch (charString) {
            case (SPACE):
                return new char[]{SPACE_CHAR, SPACE_CHAR};
            case (ALL_CHARS):
                return new char[]{FIRST_ASCII, LAST_ASCII};
        }
        if (charString.length() == 1 && charString.charAt(0) != SPACE_CHAR) {
            return new char[]{charString.charAt(0), charString.charAt(0)};
        }
        else if (charString.length() == 3 && charString.charAt(1) == CHAR_HYPHEN)
        {
            if (charString.charAt(0) < charString.charAt(2)){
                return new char[]{charString.charAt(0), charString.charAt(2)};
            }
            return new char[]{charString.charAt(2), charString.charAt(0)};
        }
        else {
            System.out.println(ERROR_INVALID_ADD_FORMAT);
            return null;
        }
    }

    private void showChars(){
//        charSet.stream().sorted().toList().forEach(character -> System.out.print(character + " "));
        charSet.stream().sorted().forEach(character -> System.out.print(character + " "));
        System.out.println();
    }

    private void addChars(String charString) {
        char[] range = parseCharRange(charString);
        if(range != null){
            for (int i = range[0]; i <= range[1]; i++) {
                char c = (char) i;
                charSet.add(c);
            }
//            Stream.iterate(range[0], c -> c <= range[1], c -> (char)((int)c+1)).forEach(charSet::add);
        }
    }

    private void removeChars(String charString) {
        char[] range = parseCharRange(charString);
        if(range != null){
            for (int i = range[0]; i <= range[1]; i++) {
                char c = (char) i;
                charSet.remove(c);
            }
//            Stream.iterate(range[0], c -> c <= range[1], c -> (char)((int)c+1)).forEach(charSet::remove);
        }
    }

    private void changeResolution(String changeResolutionStr) {
        switch (changeResolutionStr) {
            case RES_DOWN:
                if (charsInRow / RESOLUTION_FACTOR >= minCharsInRow)
                {
                    charsInRow /= RESOLUTION_FACTOR;
                    System.out.println(WIDTH_SET_TO + charsInRow);
                }
                else {
                    System.out.println(RESOLUTION_ERR_MSG);
                }
                break;
            case RES_UP:
                if (charsInRow * RESOLUTION_FACTOR <= maxCharsInRow)
                {
                    charsInRow *= RESOLUTION_FACTOR;
                    System.out.println(WIDTH_SET_TO + charsInRow);
                }
                else {
                System.out.println(RESOLUTION_ERR_MSG);
                }
                break;
        }
    }

    private void render(){
        Character[] arr = new Character[charSet.size()];
        char[][] charMatrix = brightnessImgCharMatcher.chooseChars(charsInRow, charSet.toArray(arr));
        if (console) {
            for (char[] row : charMatrix) {
                for (char character : row) {
                    System.out.print(character);
                }
                System.out.println();
            }
        }
        else {
            asciiOutput.output(charMatrix);
        }
    }

    public void run() {
        System.out.println(CONSOLE_GUI);
        String command = input.next().trim();
        while (!(command.equals(CMD_EXIT)))
        {
            String nextCommand = input.nextLine().trim();
            switch (command) {
                case ADD_CHARS:
                    addChars(nextCommand);
                    break;
                case REMOVE_CHARS:
                    removeChars(nextCommand);
                    break;
                case SHOW_CHARS:
                    showChars();
                    break;
                case RENDER:
                    if (nextCommand.length() > 0){
                        System.out.println(RENDER_FORMAT);
                        break;
                    }
                    else if (charSet.isEmpty()) {
                        break;
                    }
                    render();
                case CONSOLE:
                    if (nextCommand.length() > 0){
                        System.out.println(CONSOLE_FORMAT);
                        break;
                    }
                    console = true;
                    break;
                case RES_CHANGE:
                    changeResolution(nextCommand);
                    break;
                default:
                    System.out.println(INVALID_COMMAND_ERROR);
            }
            System.out.print(CONSOLE_GUI);
            command = input.next();
        }
    }
}
